📘 README – Nameplate Ranking System

Created by dedou3d 💠

🥉 RANK 1 — Basic Setup

Add the following section to your custom-placeholders.yml file.It enables dynamic switching of the top image on nameplates based on the flower style equipped by the player.

🥌 RANK 2 — Enable Required Modules

In your main configuration file, make sure these modules are enabled:

modules:
  nametags: true         # Enables nametags
  nameplates: true       # Enables nameplates

🥇 RANK 3 — Plugin Integration

Enable only the integration that matches the plugin you're using:

nexopack: true (for NexoPack users)

itemadder: true (for ItemsAdder users)

oraxen: true (for Oraxen users)

📌 Only one integration should be enabled based on your setup.

🏋️ RANK 4 — In-Game Testing

To test or equip a nameplate in-game, use the command:

/nameplates equip and choose

🏆 RANK 5 — Purpose

This setup automatically changes the top visual of a nameplate based on the equipped flower (color and tier).It creates a unique and immersive visual identity for players.

🎖️ RANK 6 — For Creators

A powerful tool to build visual progression, identity, or status-based styles for:

RPG environments

Class or faction systems

Dynamic visual rankings

Created by dedou3d 💠
# 582DFBAX5C08NK8PI8FM3JU1C4NZ